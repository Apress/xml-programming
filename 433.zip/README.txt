This is a README file that accompanies the code archive
for XML Programming by Tom Myers and Alexander Nakhimovsky.

Also in the archive are two sub-archives, xmlp.zip and
xmlpasp.zip. They should be unzipped, with the directory
structure preserved, into the following directories:

xmlp.zip: TOMCAT_HOME/webapps (both Windows and Linux)
xmlpasp.zip: inetpub\wwwroot (Windows only)

Detailed installation instructions are in Appendix A.
The xmlp.zip archive has a readme.htm file with further
instructions and latest updates.

Appendix A mentions (p. 499) a separate Linux archive. In the
end, we have merged both Windows and Linux code into a single
xmlp.zip archive. It does contain a separate linux-readme.htm
file, reachable from the general readme.htm. The code in
xmlasp.zip is Windows-specific.
